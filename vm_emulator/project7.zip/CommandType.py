from enum import Enum

class CommandType(Enum):
    ARITHMETIC = 0
    PUSH = 1
    POP = 2